#!/bin/bash

diff execuser_windows.go <(curl https://gist.githubusercontent.com/LiamHaworth/1ac37f7fb6018293fc43f86993db24fc/raw/2cfaf36cd326ace04c000fb988a5ef6b1f02a116/native.go)

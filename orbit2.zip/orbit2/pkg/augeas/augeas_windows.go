//go:build windows
// +build windows

package augeas

func CopyLenses(installPath string) (string, error) {
	return "", nil
}

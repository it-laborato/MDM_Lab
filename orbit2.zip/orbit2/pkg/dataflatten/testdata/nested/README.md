Some simple shell/ruby/make hackery to get a nested plist

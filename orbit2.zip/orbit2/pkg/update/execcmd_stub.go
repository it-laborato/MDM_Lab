//go:build !darwin

package update

func runRenewEnrollmentProfile() error {
	return nil
}

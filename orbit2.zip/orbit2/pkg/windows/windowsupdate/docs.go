// Package windowsupdate provides a go-ole interface to the windows
// update agent.
//
// This code derives from https://github.com/ceshihao/windowsupdate
// based on github.com/kolide/launcher/pkg/osquery/tables
package windowsupdate
